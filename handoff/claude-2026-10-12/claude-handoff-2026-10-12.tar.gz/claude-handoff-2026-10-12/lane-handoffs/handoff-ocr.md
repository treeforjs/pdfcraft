# OCR and paused PhotoCraft handoff for Claude

User requested stopping after current work and handing off. No OCR integration, build, commit or push was performed. The OCR source is **uncompiled and not ready to merge**. An independent review identified the permission issue below before the stop; it remains unfixed to preserve the exact frozen patch requested by the parent.

## OCR source and integration boundary

- Worktree: `/workspace/pdfcraft-ocr`
- Branch: `feature/pdf-ocr-parity-2026-10-12`
- Base: `6cab152bc24f80629627ad928e327027088727c4`
- Frozen patch: `/workspace/ubuntu-support/full-parity-2026-10-12/pdfcraft-ocr-review-source.patch`
- Patch SHA-256: `5b189631fd232f102215b577dd2e877ef9df6764575f2e1f3d5e52dbc6759831`
- Exact 15-file and model hashes: adjacent `pdfcraft-ocr-review-source.json`. All source hashes were reverified when writing this handoff.
- No Cargo target was created in this worktree. No OCR Cargo invocation or active OCR/Photo build remains.
- Root intended contextual integration into `/workspace/pdfcraft` followed by use of its consolidated `target/agent-parity`, after other PDF lanes. **This was canceled by the stop instruction.** Do not whole-file-copy shared modules over other agents' changes.
- Narrow shared seams: `crates/engine/src/lib.rs` AddOcrText writer now returns Result; automation `lib.rs` module/state/dispatch/close cleanup, `a11y.rs` settings validation, `tools.rs` five schemas; roadmap and OCR parity entry. Remaining source is OCR-owned files and new tests.

## Intended first workflow

Recognition results remain a private draft bound to source DocId, edit generation and bytes. Review and correct a word, omit it with empty text, then apply once or cancel. Default GUI flow opens review; synchronous `ocr_recognize` retains direct recognize-and-apply behavior. New tools: `ocr_prepare`, `ocr_review`, `ocr_correct`, `ocr_apply`, `ocr_cancel` (1-based page/word).

Cancellation before/after rendering, after inference and at final completion discards the entire draft; it no longer commits completed pages. Model inference itself is not interruptible. Edits, undo/redo, save or closing the source invalidate its draft. Geometry is preserved during correction, invisible text uses q/Q to restore text rendering mode, and source images are unchanged.

Bounds added: finite 72–600 dpi, unique existing pages, 40 million pixels/16,384 pixels per side before rendering/conversion, exact packed gray/RGB/RGBA lengths, finite/nonzero word edges, 200,000 words/16 MiB per page, one million words/64 MiB per draft, 16,384 UTF-8 bytes per corrected word. RGBA inference input composites over white. Backend panics return an error without applying text. Automation retains at most eight drafts; close releases its draft.

The bundled model is ASCII/English. Corrections safely support WinAnsi accents; unsupported Unicode is rejected before mutation. No multilingual model, confidence scores, scanner driver or new backend was added. Correction of an already-saved OCR layer is not implemented. The parity entry is **partial** and percentages are unchanged.

## Blocking read-only review finding — fix before integration

`ocr_job_checked` currently checks `read_only_reason` but not the document's actual copy/modification permission flags. A restricted encrypted document may have an editor and no read-only reason; prepare then renders, recognizes and returns text before the ordinary `Session::apply` permission check. This is inconsistent with the newer reader/text-extraction policy. `ocr_review` also serializes a stored draft even when `validate_ocr_review` returns an error.

The intended fix should enforce the appropriate copy + modification authority before rendering/inference and before returning/correcting draft text, with owner-password override. Revalidate against the current document when exposing a draft, not only at apply. Add encrypted synthetic tests for: copy denied/modify allowed; copy allowed/modify denied; both denied; owner allowed; and a previously allowed draft whose source permissions/revision later change. Assert rejection before backend invocation and no text/data/history mutation. Coordinate with the integrated reader's copy-permission helper rather than introducing a divergent policy. Agent `/root/parity_runtime` reported this; review was unfinished when stopped, so additional findings may remain.

## Verification completed and pending

Completed only:

- `rustfmt` on changed Rust sources and `git diff --check`.
- Exact source/model hash verification.
- A **baseline** actual-model CLI probe against the retained checkpoint binary, described below. It does not test the new source.

No OCR crate, engine, UI, automation, lint, WASM, workspace or installed acceptance test of this patch has run. Do not report new tests as passing. Planned focused gates after fixing review findings and contextual integration:

1. `cargo test -p pdfcraft-ocr --lib`
2. `cargo test -p pdfcraft-engine --test ocr_review`
3. `cargo test -p pdfcraft-automation --test ocr_review`
4. `cargo test -p pdfcraft-ui-egui --test ocr`
5. Existing actual-model engine `recognize_text_makes_a_scanned_page_searchable` and automation OCR cases, tool-table test, required strict lint/full workspace/WASM/assets/parity gates.
6. Real CLI and GUI review/correction/cancel/apply/save/reopen, inspect image evidence. Ensure packaged model execution, not internally skipped tests.

Use `source /workspace/native-deps/env.sh`, `CARGO_BUILD_JOBS=1`, `CARGO_INCREMENTAL=0`, debug=0, and the parent-coordinated target. Do not set PKG_CONFIG_SYSROOT_DIR. Watch disk; last observation was approximately 2.7 GiB overlay and 2.9 GiB /tmp free. Shared target reuse must be scheduled with the parent to avoid feature/path churn.

Tests added:

- `crates/engine/tests/ocr_review.rs`: review/correct/save/reopen pixel equality and one undo; every two-page cancellation boundary; stale edit/undo/redo/save/close; bad settings/pages/words/corrections; oversized page preflight without backend invocation; caught backend panic; later visible text after Tr3; rotated page geometry.
- `crates/automation/tests/ocr_review.rs`: bad inputs; actual-model prepare/correct/cancel/apply/undo/save/reopen/root confinement/stale rejection. Save test uses the task-local original path to assert incremental saving; Save As intentionally uses a full rewrite.
- `crates/ui-egui/tests/ocr.rs`: existing recognition test now explicitly clicks review Apply; new real-model correction navigation/Escape/stale test.
- OCR crate unit tests: dimensions/channels/transparent input/WinAnsi and bad geometry; existing text-layer assertions updated for balanced q/Q.

Potential compilation or behavior fixes remain because no Cargo has run. Review UI borrowed-state/window handling, kittest focus/accessibility queries and all model-backed branches rather than assuming source inspection proves them.

## Verified models and baseline probe

Models were extracted only from the exact new package, without downloading or adding assets:

`/workspace/ubuntu-support/full-parity-2026-10-12/pdfcraft/pdfcraft-0.5.0+parity2-linux-x86_64.deb`

They are in ignored `/workspace/pdfcraft-ocr/assets/models` with both license files and attribution. Hashes match existing ATTRIBUTION.toml:

- detection: `f15cfb56bd02c4bf478a20343986504a1f01e1665c2b3a0ad66340f054b1b5ca`
- recognition: `e484866d4cce403175bd8d00b128feb08ab42e208de30e42cd9889d8f1735a6e`
- license text: `28a9529c7d0bb4dc51f4bf5c116a3d16ef247a052f7591466768ddf563fd1cf5`

Set `PDFCRAFT_MODELS=/workspace/pdfcraft-ocr/assets/models` for actual model gates. The package installs them at `/usr/share/pdfcraft/models`; earlier absence from host assets did not imply a packaging defect.

Baseline evidence directory:
`/workspace/ubuntu-support/full-parity-2026-10-12/evidence/pdfcraft/ocr-baseline`

`summary.json`, `sha256.json`, `fixture-provenance.json`, `steps.json`, `cli-results.json`, `cli-stderr.log`, original generated PNGs and searchable PDF outputs are retained. `cli-results.json` is concatenated CLI JSON results, not one JSON array; `summary.json` is ordinary JSON.

Original three-line synthetic fixture uses existing allowed Inter-Regular.ttf (OFL-1.1); no proprietary fonts or assets. Retained checkpoint CLI with packaged models recognized upright text exactly (21 words). At 90° it returned zero words; at 180° it returned 13 nonsense words. At +5° recognition was exact but extracted reading order/spacing was wrong; at −5° two recognition errors plus reading-order errors occurred. These are observations on five synthetic cases, not general accuracy or performance claims. No quiet timing was attempted.

## Next OCR work after the first patch is green

Prioritize actual orientation/deskew and placement/reading-order correctness using those fixtures. Existing PDF /Rotate mapping already works; automatic detection is a separate feature. Preserve the original image in exact mode and map transformed recognition boxes back through a documented affine transform. Do not label a manual rotation selector as automatic detection or claim arbitrary scan cleanup from inference-only preprocessing.

Multilingual recognition needs both a model trained for the target script and Unicode/font-safe searchable output. `ocrs` 0.13.1's default alphabet is ASCII and TextChar exposes no calibrated confidence; changing labels/alphabet alone is not a solution. Tesseract 5.5.0 is installed here with eng/osd only and is an Apache-2.0 independent oracle/optional native-backend candidate; no integration or additional language download has occurred. Official model provenance, native/WASM deployment, bounded subprocess/cancellation and output encoding still need a deliberate implementation. Paddle-family models likewise need model-specific license/runtime verification.

`remaining-inventory.json` enumerates the repository's 27 OCR feature rows, including language support, editable output, downsample, automatic rotation/deskew, despeckle/background/descreen/halo/shadow cleanup, camera correction, MRC, PDF/A, engine selection, web models, scanner acquisition/presets/append. Adobe cloud sync is explicitly not applicable. Repository checklists are not proof of proprietary reference parity.

## PhotoCraft remains paused

Source: `/workspace/photocraft`, branch `feature/full-parity-2026-10-12`, base `b1ec586d58e6937d52dd90a1fdc654bebe2972ff`. All continuation changes remain uncommitted; no push. Preserve them and all caches unless coordinated.

Primary receipt: `/workspace/ubuntu-support/full-parity-2026-10-12/photocraft-paused-for-pdf.json`; patch snapshot `photocraft-paused-tracked.patch`. That receipt records 51 source hashes, complete logs and exact outstanding gates. It includes Hue/Colorize Smart adjustments, mask painting/live cancel/undo, stack UI and strict baseline lint cleanup. Normal opacity preserves native premultiplied coverage; non-Normal restored existing source-over behavior after the oracle investigation.

Native before final blend correction: 4,757 passed/41 ignored over 14 completed batches; broader run stopped on PDF reprioritization. Initial full release corpus failed the unchanged floor; the narrow correction passed two formula and two oracle tests, restoring five passing Smart Filter fixtures (overall floor5/86, Smart5/30, text0/56). **Full corpus and full native validation of the final source are not complete.** Focused logs: `logs/photocraft-coverage-correction-{build,formulas,oracles}.log`; comparison evidence: `evidence/photocraft/oracle-investigation/`.

Remaining Photo gates before commit: remaining native targets and affected rerun, full corpus, final strict lint/WASM/panic_hunt, 24MP developer/release preview and quickperf, visual evidence, build receipt/package/installed acceptance. Deferred Photo features: filter-mask feather/density, native deterministic Dissolve, Warp Text and larger selection/content-aware workflows. Prior wave1 packages/evidence are unchanged.

Retained Photo targets: `/workspace/photocraft/target/agent-parity` and `agent-parity-tools`; release symlink to `/tmp/artcraft-full-parity-release/photocraft`, WASM symlink to `/tmp/artcraft-full-parity-wasm-cache/photocraft`. No current Photo jobs or timing window.
