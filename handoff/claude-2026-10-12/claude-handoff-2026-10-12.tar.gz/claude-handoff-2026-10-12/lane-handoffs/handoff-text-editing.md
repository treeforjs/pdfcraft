# PdfCraft text editing handoff — paused for Claude

User requested finishing the current checkpoint and pausing further work. No new compilation or
feature work is running in this lane. The verified checkpoint and the unverified next draft are
separate. Do not describe the underline draft below as delivered or tested.

## Verified, pushed checkpoint

- Main repository: `/workspace/pdfcraft`.
- Commit: `994698dde20a97cc41eccd17552f1797d7dd2298`, **M7: edit selected text runs and preview the actual PDF**.
- Parent reports this commit pushed. Parent owns package/push/integration records.
- Native final gate: **1,809 passed, 0 failed, 5 ignored in 85 target batches**.
- Final strict workspace/all-target Clippy, formatting, 30-crate WASM, assets, layers, parity references,
  dependency advisories/bans/licenses/sources all passed. These gates apply to 994698d, not the draft.
- Normal desktop, CLI and xtask built from clean 994698d with a provenance receipt.
- New CLI and external Poppler synthetic-fixture oracle passed; preview and accepted PNG matched.
- Installed acceptance: runtime reports **12/12 cases passed** on Ubuntu 24.04/26.04 × X11/Wayland ×
  baseline/retained/new workflow cases, first attempt, without harness correction.
- I visually inspected the Ubuntu26 Wayland rendered preview, saved/reopened mixed paragraph, and
  selected Type3/reflow PNGs. They preserve the requested independent faces and blue block glyphs.

Evidence:

- `/workspace/ubuntu-support/full-parity-2026-10-12/pdfcraft-source-validation.json`
  (source gates/build/oracle; this older receipt deliberately says the then-pending installed matrix
  was owned externally, so use the installed checkpoint receipt too).
- `/workspace/pdfcraft/target/agent-parity/debug/parity-build-receipt.json`.
- `/tmp/pdfcraft-full-parity-targets/results.json` and the corresponding per-target logs.
- `/tmp/pdfcraft-full-parity-poppler.log` and `/tmp/pdfcraft-full-parity-oracle/result.json`.
- `/workspace/ubuntu-support/pdfcraft-checkpoint-2026-10-12/` contains runtime/package snapshots and
  results; snapshot name `pdfcraft-checkpoint-0aa5baff428e4928b3228a853577f6f9`.
- Images inspected under
  `results/ubuntu26/pdfcraft-checkpoint-0aa5baff428e4928b3228a853577f6f9/feature-wayland/`:
  `draft-rendered-preview.png`, `mixed-paragraph-reopened.png`, `reflow-reopened.png`.

The checkpoint supplies Unicode-scalar range formatting, exact existing-font selection, preserved
source glyph codes/TJ and supported text state in mixed/selected edits, atomic refusal, redo-safe
no-op edits, and a bounded actual-PDF draft preview. It does **not** establish full Acrobat parity.

## Frozen unverified next draft

- Worktree: `/workspace/pdfcraft-text-next`.
- Branch: `feature/pdf-text-parity-next-2026-10-12`.
- Base HEAD: exactly `994698dde20a97cc41eccd17552f1797d7dd2298`.
- **13 modified/new files, uncommitted. No compile, tests, Clippy, WASM, assets, parity or runtime
  checks have been run for this draft.** `cargo fmt --all` completed and `git diff --check` passed.
- Main was not touched by this lane after checkpoint packaging. Other lanes may now have their
  own parent-authorized integrations in main; do not reset them.

Exact backup artifacts, all beside this handoff:

| Artifact | SHA-256 |
| --- | --- |
| `text-editing-unverified-2026-10-12.patch` | `580b9e82100e7b7f20a440d796454ea179efdf3fd603248010cc75371e242dab` |
| `text-editing-unverified-2026-10-12.tar.gz` | `476dd82841780fe8829a32c5829e3ca00123b60c8d14bd3e559d44046c48b837` |
| `text-editing-unverified-2026-10-12-source-hashes.json` | `54944406def52ff41c9fdc6fbf1407193934f2f10d89a79c3ef67a1389eb94bc` |

The patch contains tracked-file changes only. The tar archive contains complete bytes of all 13
changed/new files, including untracked `crates/edit/src/text/decorations.rs` and
`docs/editable-underlines.md`. The manifest lists every source path, byte count, hash and untracked
status. Prefer the existing worktree; the artifacts are a recovery snapshot. Do not apply both patch
and complete-file archive to the same tree without checking what is already present.

### Implemented in the draft, not verified

1. **Persistent selected underlines.** New `edit/src/text/decorations.rs` associates each authored
   underlined glyph with exactly one authored underline path, using two private BDC/EMC markers,
   version 1 and a unique positive page-local integer ID. No Adobe code/assets/data were used.
2. **Read-back and precise removal.** TextRun now reports `underline`. Parser pre-scans joined
   content streams; valid associations become run state. Replacement removes only complete pairs
   belonging to replaced text-showing operations and regenerates paths during reflow. Missing,
   duplicate, malformed or unknown-version text associations cause atomic refusal. Unmarked
   imported/older PdfCraft paths remain artwork. The convention is not cryptographic provenance.
3. **Path integrity.** The accepted path sequence is `q cm RG w J d m l S Q`, with finite values,
   exact counts, solid dash and butt caps. It is emitted outside BT/ET and restores graphics state.
   Nested invalid markers use sorted invalid intervals plus a single operator scan to avoid
   repeatedly scanning inner bodies. Maximum indexed pairs is 1,000,000.
4. **Appearance safeguards.** Underline color is derived only from known device Gray/RGB/CMYK;
   other color spaces require choosing RGB first. Source sizes must be positive/finite. Inferred
   logical spaces get an encodable space if needed for an underline association. Text encountered
   with an unpainted current path is marked unsupported because q/Q does not save the current path.
5. **Adjacent artwork protection.** Legacy line/whole-paragraph coincident removal was narrowed
   from >50% rectangle overlap to identical Unicode text, source glyph codes/adjustments, supported
   state and transform, with near-identical geometry. This preserves independent overlapping
   labels/OCR/decorated text while retaining exact fake-bold copy removal. This change needs the
   existing fake-bold and overlap suite rerun.
6. **UI/automation.** Selected underline button is enabled. Selection/source refresh updates
   underline state, and the approximate typing layout draws it. Automation `text_paragraphs` adds
   `runs[].underline`; `text_edit` already accepts underline and now supports selected ranges.
   Exact PDF preview uses the same edit path. No new translatable strings were added; an unused
   older whole-paragraph-only tooltip remains in locale catalogs.
7. **Tests written, not run.** Edit regressions cover on/off, no-op bytes, replacement/reflow/style
   preservation, malformed/missing/duplicate path refusal, active paths/dash state, split tokens,
   shared page streams, two paragraph IDs and overlapping independent labels. Automation test
   covers visible pixels, preview/accepted PNG equality, metadata, save/reopen, undo/redo and no-op
   redo preservation. UI test uses real keyboard range selection and underline/italic controls.
8. **Docs drafted.** `docs/editable-underlines.md`, automation README/tool description and the
   bold/italic/underline parity note/evidence list are updated in source. They must be treated as
   unverified draft claims until the cited new tests execute. No parity status was upgraded.

### Immediate review/verification needs

- First compile only the edit crate using the shared target, then run focused edit tests. The draft
  has never been through rustc, so basic compiler/lint errors are possible. In particular inspect
  the new marker parser and fixture helper imports, then its strict operand validation.
- **Pending memory concern, not implemented before the stop:** the current 1,000,000-character
  input ceiling can still expand to many millions of output operators (each glyph replays text
  state; underlines add two markers and a path). Consider a checked output-operator budget before
  allocating the emitted `Vec<Op>`, with atomic-refusal regression. Existing style-segment and
  character caps alone do not tightly bound this new expansion. An estimated per-glyph budget can
  be checked during preparation; do not silently truncate text.
- Confirm empty-code logical spaces, negative TJ adjustments, partial font/style changes and
  line wrapping retain associations and exact positions. The reflow tests are source-only.
- Exercise malformed/forged metadata, ID exhaustion, cross-stream tokens, inherited/shared
  resources and two page placements. The metadata syntax authenticates structure only.
- The legacy `line` editing interface now refuses authored-underlined lines and directs callers to
  paragraph editing. This is an explicit interim boundary, not complete line-edit parity.
- `pending_path` currently causes the paragraph rewrite refusal for any changed paragraph with an
  active path, not only underline changes. This is conservative and should be documented/tested.
- Underline removal routes through mixed reflow. Rotated/skewed/reflected geometry still refuses.
- Existing `justify_underline_and_spacing`, fake-bold, selected-character UI, pixel fidelity,
  ligature/subset refusal, oversized-input, preview/permissions and shared-resource regressions
  must pass, followed by required full gates, clean commit, build receipt, package and installed
  acceptance. Do not reuse 994698d's gate evidence for this draft.
- Add/update ROADMAP only after the milestone is verified; it was intentionally not marked done.

## Planned work, no implementation yet

1. **Uniform paragraph source preservation.** Route supported upright whole-paragraph changes
   through the run/glyph preservation path instead of legacy whitespace normalization/re-encoding.
   Keep fake-bold behavior narrowly defined and preserve unrelated overlays. This touches wrapping,
   leading, spacing and old test expectations, so do not simply route everything without tests.
2. **Transformed mixed runs.** Use one common local text frame with normalized X/Y basis and an
   inverse affine transform for grouping, gap advances, row baselines and widths. Keep separate
   horizontal/vertical scale magnitudes. Current page-X/rectangle grouping and inferred gaps are
   unsuitable for rotated/skewed/reflected text. Retain actual source end points and project them;
   merely deleting the upright guard would corrupt placement. Cover CTM/Tm rotations, shear,
   nonuniform scale, reflection, source TJ, independent rises, outside-run pixels and reflow.
3. **Tr0–3 and stroke/ExtGState.** Capture/replay complete stroke color space/color, line width,
   dash/cap/join/miter and rendering mode with q/Q semantics. Define how requested text color acts
   on stroked glyphs. ExtGState opacity/blend/soft masks and Tr4–7 clipping need separate complete
   reconstruction, including clipping lifetime through ET and q/Q. Current refusal is deliberate.
4. **Further full-parity queue.** Tagged-content/paragraph identity, imported decoration recognition,
   broader fonts/encodings/shaping, find/replace and complex layout. Inventory:
   `docs/parity-inventory-2026-10-12.md` (830 rows; 420 shipped labels, 73 partial, 314 planned, 23 NA
   at checkpoint; labels/reference tests do not establish feature equivalence).

## Build/resource and integration context

- Source `/workspace/native-deps/env.sh`; no `PKG_CONFIG_SYSROOT_DIR`.
- Shared target `/workspace/pdfcraft/target/agent-parity` only; jobs 1, incremental 0,
  dev/test debug 0. Do not create duplicate targets or launch concurrent competing native builds.
- WASM target path is a verified symlink to
  `/tmp/artcraft-full-parity-wasm-cache/pdfcraft`; preserve it and normal binaries/rlibs/rmeta.
- At stop, overlay free space was approximately 2.0 GiB; /tmp about 2.9 GiB. Parent coordinates
  build slots and verified generated-test executable cleanup.
- Reader selection, OCR, signatures, preflight and renderer lanes have separate worktrees.
  Shared automation/lib.rs/tools.rs and UI hooks must be integrated surgically. Reader lane may
  change render/text.rs; this editing lane has not touched that file. Preflight owner had the main
  focused compile slot at stop. See parent handoff for current integration status.
- Follow AGENTS.md/CLAUDE.md, public specs and original synthetic fixtures only. No Adobe visual
  assets/code; no committed font files. Font fallback remains optional craft-fonts input.

Resume only according to the user's next direction; the requested stop is now honored.
