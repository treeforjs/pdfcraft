# Runtime and independent review handoff for Claude

Recorded at the user's stop request on 2026-10-12 by `/root/parity_runtime`.
No new builds, source changes, or application acceptance should be inferred from this handoff.
This agent has no running shell/Cargo/GUI session. Root and source owners own any other sessions.

## Completed and frozen PdfCraft checkpoint

Source commit: `994698dde20a97cc41eccd17552f1797d7dd2298`, pushed by root on `feature/full-parity-2026-10-12`.
Package: `/workspace/ubuntu-support/full-parity-2026-10-12/pdfcraft/pdfcraft-0.5.0+parity2-linux-x86_64.deb`.
SHA-256: `3c7b38f5ec87648297c6e15f6f6e2ae11457a2fd60853ed533a716c0e8c69f10`.
Debian version: `0.5.0+parity2-1`.
Installed GUI hash: `9a03d3f60028c738fe08618876f76ba73bbf4610abfa1d38c867329b47652769`.
Installed CLI hash: `297d1a2d05b2b0c10ea3d5c221559e63633d376b7b61893ffb50fa4c1a94fbbf`.

Dedicated immutable harness/evidence directory:
`/workspace/ubuntu-support/pdfcraft-checkpoint-2026-10-12`.

Important files within it:

- `pdfcraft/BUILD-RECEIPT.json`: exact source/build/actual DEB identity.
- `HARNESS-INPUTS.json`: all 13 frozen harness execution-input hashes.
- `SNAPSHOT.json`: precise provenance from the mutable all-app workbench.
- `container-preflight.json`: ordinary-user setup and external helper identities before acceptance.
- `pdfcraft-checkpoint-0aa5baff428e4928b3228a853577f6f9-validation.json`: immutable passed aggregate.
- `screenshot-index.json`: all 52 retained PNGs, grouped by all 12 case keys. This index was made before root visual review; the completed visual record is in the manifest below.
- `PDFCRAFT-CHECKPOINT.json`: root's completed PDF-only distribution manifest, exact pushed source, all 12 verified cases and all 12 visual-review groups passed.
- `validate_pdf_checkpoint.py`: PDF-only gate reusing the complete per-item verifier. It does not authorize the pending Photo/Vector combined release.
- `gate-tests.log`: root's synthetic stale/missing/provenance gate checks.
- `results/ubuntu24/` and `results/ubuntu26/`: immutable install logs/records and attempt evidence.

Fresh attempt name: `checkpoint-0aa5baff428e4928b3228a853577f6f9`.
Both disposable containers installed the exact verified DEB. All 12 cases passed on their first attempt with **no source or harness correction**:
Ubuntu 24.04/26.04 × X11/Wayland × baseline/retained font chooser/new mixed-run preview workflow.

The new workflow proved selected bold/italic preserves surrounding styles; draft preview does not change PDF bytes/history; the proposed render PNG exactly equals the accepted render PNG; Unicode-scalar ranges, exact original Type3 font choice, reflow, undo/redo and save/reopen work; invalid ranges/glyphs and unsupported stroking/graphics-state edits refuse atomically. All fixtures are contributor-original. Root visually reviewed all 52 PNGs. I independently viewed the X11 draft preview and found the styled prefix, normal neighbors and action buttons coherent.

This is a development checkpoint, **not full Acrobat parity**. Software Mesa in disposable containers is the graphics backend. Physical NVIDIA/Intel hardware, native Windows, real GNOME sessions and printing are unverified. Optional craft-fonts CJK input is absent.

No more acceptance is needed for this exact checkpoint. Do not mutate its frozen harness to attach future evidence; make another snapshot/attempt for future source/package identities.

## Cleared source reviews: preflight and reader selection

Preflight worktree: `/workspace/pdfcraft-preflight`; owner `/root/parity_photocraft/photo_smart_review/mask_tests`.

- Initial blocker: the bounded object traversal cloned all owned path keys for every queued sibling. A 40-level, 256-byte-key chain followed by approximately 249,000 array entries could duplicate more than 2.5 GB of key bytes from compact input.
- Corrected using shared `Arc<PathNode>` ancestry; only retained finding paths materialize, with a separate 4 MiB key-byte budget plus existing count/depth limits.
- Rechecked owner-value/generation binding, direct nested paths, explicit selected-fix behavior, private clone/publish atomicity, cancellation, engine permissions/history and truthful structural-only conformance wording. No remaining material source blocker in the reviewed scope.
- Evidence: `pdf-preflight-initial-source-review.json` and `pdf-preflight-final-source-review.json` in this directory.
- Owner subsequently integrated into main and reported **25 focused tests passed** (15 core, 2 engine, 4 automation, 4 UI), core strict Clippy and workspace fmt/diff checks. This agent did not run those gates.
- Main-only improvements after my source review: analysis now returns success/failure, clears old result/selection, and report export aborts after failed analysis; modal body/results heights fixed after UI test found a clipped checkbox. Owner reports a dedicated regression for each.
- Owner evidence: `preflight-native.png` here; `/tmp/pdfcraft-preflight-integrated.sha256`. Root owns central gates/commit decisions. Do not label this source as installed-tested or pushed merely because the earlier checkpoint is.

Reader worktree: `/workspace/pdfcraft-selection`; owner `/root/parity_vectorcraft`.

- Fixed material gesture ownership issue: an existing selection could extend while a comment/form owned the drag. `text_dragging` is now established only after a fresh unconsumed text anchor and required for extension/autoscroll.
- Fixed same-frame cancellation ordering: Escape and Cancel win before deferred copy completion.
- Fixed deferred copy context authority: queued copy and text drag cancel on inactive tab, modal/palette, focus loss, focused text editor, organize mode and render suspension while preserving the visible selection. Completion occurs only at end-of-frame after late UI/edit actions and rereads current copy permission.
- Added progressive selection-cache bounds (2 million glyphs/32 MiB text, at most 32 missing selected pages queued); a crossing offscreen page is not cached. Changed-head-only budget reset permits shrinking/retrying without stationary-drag retry loops.
- Endpoint/Unicode/ligature handling, reading-order output, no partial copying, source invalidation and copy permission were reviewed. No remaining material blocker found in this scope.
- Evidence: `pdf-reader-selection-source-review.json`. Its production hashes are the reviewed final production state; later added context-loss/replacement tests may have changed test-file hashes.
- Owner reports source remains **uncompiled**, with 23 new tests awaiting the integration/build slot. This is source clearance only, not a runtime or test pass claim.
- Installed-harness nuance for later: control `ui.key` does not synthesize `Event::Copy` from Ctrl+C. Use actual context-menu Copy; use `ui.state.active.text_selection` and the `text_selection` headless tool. Owner sent recipes to root/runtime; preserve actual UI pointer evidence.

## Renderer: unfinished, blocking follow-ups

Worktree: `/workspace/pdfcraft-rendering`; root owns this lane. Do not integrate it as validated.
Core files: `crates/render/src/{display_list.rs,vector_raster.rs,raster.rs}`, `vector_raster/decode.rs`, original tests, and the narrowly added `vendor/hayro-syntax/src/object/stream.rs::raw_data_within`.
Evidence: `pdf-native-vector-initial-source-review.json` (captures the initial findings, not final clearance).

Reviewed coherent source invariants: path coordinates capture CTM at each construction operator; q/Q does not restore the current path; clipping installs after painting; stroke uses paint-time CTM; crop/rotation/tile transform order matches bootstrap geometry; unsupported features reject the whole native candidate. Segment/draw/state/clip-reference and coordinate/dash budgets exist. Positive/negative cache is one page per worker/parser generation.

Outstanding items at stop:

1. **Strict lexer replacement is implemented but not re-reviewed/compiled.** The initial native path called tolerant `pdfcraft_content::parse`, exposing COS number-prefix repair with quadratic rescanning before cancellation. Root replaced it with a strict linear native-subset lexer, numeric tokens ≤64 bytes, ≤256 dash items, ≤6 operands, per-token cancellation and immediate fallback for unsupported syntax. Finish reviewing that new implementation and its malformed/huge-token/comment-cancellation tests.
2. **Stream framing finding is addressed in final source, but not independently re-reviewed or tested.** The reviewed decoder had accepted filters whose missing EOD is tolerated. At the final stop checkpoint, root restricted native content to unfiltered and Flate only (Flate requires deflate StreamEnd); LZW, RunLength, ASCIIHex and ASCII85 now force whole-page fallback. Recheck this final source and its original regressions before integration.
3. **External/abbreviated stream finding is addressed in final source, but not independently re-reviewed or tested.** Root reports `/F`, `/FFilter`, `/FDecodeParms` and `/DP` are now explicitly rejected; previously these could be ignored and raw content misclassified as unfiltered.
4. **Resource review is incomplete.** Finish operation/device cost review, including inverse stroke geometry, adaptive flattening/dash work and malformed arrays. No claim of full boundedness yet.
5. Root plans independent bootstrap/Poppler comparison for anisotropic/sheared strokes, dashes/caps/joins and CTM changes after path construction. Current direct tests mostly prove fills/clips/compiler state. Root corrected direct test fixtures to specify white backgrounds because `hayro::RenderSettings::default()` is transparent; production wrapper already supplies white.
6. `raw_data_within(max)` now checks the actual encoded slice before allocating decryption output, then checks output length. Strict filter dictionary/parameter parsing and intermediate decode limits were added. Root reports all named parser/framing/entry findings corrected before freezing, but the final delta remains uncompiled, unexecuted and not independently re-reviewed. Operation/device resource review is still incomplete.

No Cargo or runtime validation of renderer source was performed by this agent.

## OCR: frozen source, confirmed permission blocker

Worktree: `/workspace/pdfcraft-ocr`; owner `/root/parity_photocraft`.
Frozen 15-file source receipt: `pdfcraft-ocr-review-source.json` in this directory, patch adjacent. Owner was told to preserve it unchanged at the stop request; not integrated/compiled.

**Confirmed blocking finding, accepted by owner:** new `ocr_prepare` can expose recognized text before apply checks edit permissions. `ocr_job_checked` checks `read_only_reason` but protected documents can still have an editor with copy and modify permissions denied. The older worktree also lacks reader's new copy guard. Apply-time checking alone is insufficient for the new prepare/review/correct JSON and UI outputs.

Before integration, enforce appropriate **copy and modify rights before job construction/render/inference and before exposing review/correct results**, with encrypted original fixtures proving refusal and owner-password override. Owner agreed to this exact pre-integration follow-up rather than changing the frozen source during handoff.

Only partial OCR review was performed: source version/bytes authority, draft correction/geometry validation, bounded image settings and q/Q invisible text setup were read. Full cancellation, global batch bounds, UI state and output semantics review remains unfinished. Do not treat it as cleared. Actual-model automation/UI tests were added by owner but are uncompiled.

Verified OCR models are available without downloads inside the exact checkpoint DEB above and in both containers at `/usr/share/pdfcraft/models/`:
`text-detection.rten` (2,510,284 bytes), `text-recognition.rten` (9,716,568 bytes), both `.LICENCE.txt` files and `ATTRIBUTION.txt`. Reuse narrowly and verify the `ATTRIBUTION.toml` pins. Packaging deleted its redundant staging directory. The 12 installed checkpoint cases did **not** claim actual OCR inference acceptance.

## Other preserved work and operating constraints

- Frozen wave 1 evidence remains `/workspace/ubuntu-support/parity-wave1`; do not modify it. All three apps' old 24-case matrix and the old all-seven combined installer acceptance had passed.
- Current all-app mutable workbench is this `full-parity-2026-10-12` directory. Its global combined release gate still fails closed while Photo/Vector registry entries are pending. PDF-only readiness does not authorize a combined milestone.
- Original opt-in hardware collectors remain `collect-hardware-ubuntu.sh`, `Collect-Hardware-Windows.ps1`, and `HARDWARE-HELPERS.md`. They collect allowlisted observed OS/adapter/driver/API/app identity without usernames/hostnames/serials or privileged changes, downloads or telemetry. Adapter detection never marks hardware tested. Windows helper has static review only because Windows/PowerShell runtime is unavailable here.
- Docker wrapper `/workspace/ubuntu-support/docker-local`; only disposable `craft-ubuntu24` and `craft-ubuntu26`, ordinary `craft-test` UID 1001. Do not install packages on the host/workstation. `/workspace/ubuntu-support` is private mode0700; narrow docker-cp files, never chmod the private root.
- Acceptance namespaces: dedicated container results `/tmp/pdfcraft-checkpoint-2026-10-12-results`; old namespaces retain prior evidence. Installation runners removed only their copied temporary DEBs.
- Existing source/asset rules remain: no Adobe assets or proprietary test screenshots; only original synthetic fixtures; system-font fallback disabled in published/local acceptance screenshots.
- No physical NVIDIA RTX PRO2000/4000 Blackwell, GeForce30/40/50, Intel integrated GPU, Windows runtime, real GNOME desktop or printer is available. Do not relabel software Mesa or compile checks as hardware proof.

## Storage/provenance notes

Root-authorized owner-acknowledged cleanup already completed; do not repeat blindly. Records in this directory preserve hashes/inodes/log provenance:

- All three inactive WASM target trees moved with verified hashes/counts/metadata to `/tmp/artcraft-full-parity-wasm-cache/{app}`; symlinks preserve original Cargo paths. See `{app}-wasm-relocation.json`.
- `reclaimed-cache-evidence/result.json`: 18 obsolete executable paths/17 unique inodes, approximately1.29GB allocated reclaimed. Filtered/compiled outputs are not mislabeled passed tests.
- `reclaimed-scratch-targets-evidence/result.json`: only owner-confirmed obsolete `/tmp/photocraft-agent-automation` and `/tmp/photocraft-agent-parsers`, approximately2.27GB reclaimed after process/FD/maps checks.
- `reclaimed-vector-unit-evidence/result.json`: four superseded unit ELFs, approximately372MB. Failed old ruler UI log remains explicitly failed.
- `reclaimed-vector-interrupted-ci-evidence/result.json`: 59 owner-confirmed compiled-but-unexecuted integration ELFs after clean cancellation, approximately2.15GB; not passed evidence. Normal GUI/CLI/xtask, retained focused/perf binaries, libraries/metadata and current caches were preserved.
- Photo release path remains a root-authorized symlink to `/tmp/artcraft-full-parity-release/photocraft`. Source owner paused Photo work for PDF priority; preserve it unless that owner confirms obsolete outputs.
- Last observed free space after package acceptance was approximately2.7GB overlay and2.9GB/tmp; this is not a current measurement after other agents' builds. Recheck before any resumed build. Never create duplicate Cargo caches unnecessarily.
