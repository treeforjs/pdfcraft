# PdfCraft signatures lane — Claude handoff

**Frozen at user stop, 2026-10-12. This is uncompiled, untested source work, not a completed or released milestone.**

## Workspace and recovery

- Worktree: `/workspace/pdfcraft-signatures`
- Branch: `feature/pdf-signatures-parity-2026-10-12`
- Base HEAD: `6cab152bc24f80629627ad928e327027088727c4`
- No commits, merges, pushes or binary/package builds in this lane.
- Main `/workspace/pdfcraft` was not edited. Shared registration hooks are only in this isolated worktree; coordinate integration with the PDF lead's text work.
- Frozen snapshot directory: `/workspace/ubuntu-support/full-parity-2026-10-12/signatures-frozen`
- `tracked-changes.patch`: full-index binary-safe Git diff of all 24 modified tracked files.
- `new-files.tar.gz`: all 11 new files, preserving relative paths.
- `source-sha256.json`: hashes of all 35 changed/new source files.
- `receipt.json`: branch/base, exact byte counts, artifact SHA-256 and validation state.
- `git-status.txt`: frozen worktree status.

Recovery into a clean checkout of the base: apply `tracked-changes.patch` with `git apply --binary`, then extract `new-files.tar.gz` at the checkout root. Do not apply over newer main without resolving the small shared hook conflicts. Preserve the original frozen worktree until recovery is checked against the hash manifest.

## Scope implemented in source

### RFC 3161 and explicit verification time

- `crates/sign/src/timestamp.rs`: fresh random nonce for online requests; response nonce and requested-policy match; request/token version and digest-size checks; critical exclusive timeStamping EKU with signing key-usage checks; writer emits RFC GeneralizedTime instead of the former UTCTime for modern dates. Imported legacy token time parsing is retained.
- `x509.rs`: tracks EKU criticality and fails closed on malformed/repeated EKU extensions rather than treating them as unrestricted.
- `pdf.rs`: `VerificationTime::{BestAvailable, ClaimedSigningTime, At(Time)}` and `VerificationTimeSource`; list APIs accept an explicit time and return its provenance. Chosen/claimed dates do not establish trusted time. Standalone document timestamps only populate `timestamp_time` when the TSA is trusted and valid at issuance; selected-time validation checks its chain and existing DSS evidence separately.
- Existing ordinary signatures and trust APIs remain. Timestamp tests now use original runtime-generated TSA certificates with the required EKU instead of an ordinary signer certificate.

### Bounded native transport and detached save jobs

- New `crates/engine/src/signature_workflow.rs` owns transport, not the sign core.
- Serializable validated `TimestampServer` profiles, HTTPS/system TLS roots, existing ureq environment proxy behavior, no redirects or URL credentials, HTTP only for literal loopback IPs (proxy bypass for loopback), optional policy OID, 1–30 second deadline, 4 MiB HTTP response cap.
- Explicit certificate trust requirement defaults true in UI profiles; disabling it permits an untrusted token without adding trust. Token validity at issuance and nonce/policy/EKU are still checked.
- Cancellation before request, while reading, after response and at UI save boundary. A blocked socket read may remain until its global deadline; cancellation is not an instant socket abort.
- `SignatureJob` captures DocId, edit generation, original bytes identity, cloned COS and trust. It performs ordinary signing, signing with timestamp, standalone timestamp, or validated evidence plus optional timestamp without mutating Session. `check_signature_result` rejects closed/edited/replaced documents before writing a destination.
- Engine native dependencies add ureq/rustls-native-certs, already in the app graph, plus serde. **Cargo.lock has not been updated because no Cargo invocation was allowed.**

### Local DSS evidence

- New `crates/sign/src/evidence.rs` validates caller-supplied local DER: 64 files, 2 MiB per file, 32 MiB total; certificate/CRL/OCSP syntax; cryptographic association to document chains and selected evidence validity window.
- Unrelated/unverifiable CRL/OCSP data is refused before embedding. Verified revocation wins over later good data. Coverage and trust are separate results; certificates are not added to trust.
- Certificates-only/incomplete coverage remains possible with explicit notes; no claim of PAdES B-LT/B-LTA conformance. The existing low-level dss writer still accepts raw evidence, while the new user workflow validates before calling it.
- No AIA/CRLDP fetching, OS PDF-signature trust import, archive-renewal policy, or trust-list work was attempted.

### OCSP ENUMERATED correction

The real RFC fixture exposed an existing defect: `OCSPResponse.responseStatus` is ASN.1 **ENUMERATED**, but `revocation.rs` parsed it with the INTEGER-only `Tlv::u64`, and the previous synthetic crypto tests incorrectly emitted INTEGER. Added `tag::ENUMERATED`, require the proper one-byte response status, and corrected the old test encoder. New original OCSP evidence also uses ENUMERATED. This is a strict interoperability correction, not a relaxation; it has not been compiled or exercised yet.

### Automation and native UI

- New automation module plus tools `sign_timestamp`, `sign_embed_evidence`, `sign_verify`; `sign_document` can attach a timestamp. All network tools require `allow_network: true` and an explicit server object. Path inputs obey the existing automation root. Signature JSON adds selected verification time/provenance; evidence results report per-certificate coverage and notes.
- New `timestamp_ui.rs`: server profile dialog/persistence; timestamp document; local DER evidence dialog; selected-time read-only verification report; background worker/cancel/progress; revision gate before save and reopen. Worker panics are converted through the existing engine guard.
- Existing Sign as dialog gains optional server selection and explicit network opt-in. Ordinary untimestamped signing preserves its prior immediate flow.
- Server settings default empty. Opening a workflow resets network opt-in. UI state is exposed via `ui.state`; documented `ui.set` keys configure profiles, selection, consent, paths and date. Actual operations remain accessible via commands/buttons.
- Surgical hooks: engine `lib.rs`, `commands.rs`, `catalog.rs`; automation `lib.rs`, `tools.rs`, `signing.rs`; UI `lib.rs`, `commands.rs`, `dialogs.rs`, `control.rs`, `sign_ui.rs` and Cargo dev dependencies.
- `docs/signature-workflows.md` and sign README describe the candidate workflow. **Doc references to regression/OpenSSL checks describe added test sources, not successful execution.** Parity TOML/roadmap percentages were deliberately not promoted before gates.

## Validation actually performed

- `rustfmt --edition 2024 --config skip_children=true` on owned Rust source/tests: completed.
- `git diff --check`: passed after formatting.
- **No Cargo build, check, test, Clippy, native UI execution or OpenSSL test was run.**
- **No network request was made**, including local synthetic requests. All test-server code is only source so far.
- No public timestamp authority was contacted and no real document or digest was submitted.

## Test sources and intended gates (unexecuted)

New sources:

- `crates/sign/tests/support/mod.rs`: original runtime-generated TSA/root/leaf certificates using existing test-only keys; RFC CRL/OCSP constructors; original blank PDF; local TCP authority helper.
- `crates/sign/tests/timestamp_workflow.rs`: nonce/policy mismatch, critical/exclusive EKU, mandatory independent OpenSSL RFC 3161 verification.
- `crates/sign/tests/evidence_workflow.rs`: CRL+OCSP coverage, original-prefix/reopen/trust behavior, expired/corrupted evidence refusal, revocation precedence, limits/unsigned refusal, mandatory OpenSSL CRL/OCSP verification.
- Existing sign `pdf.rs` tests: proper TSA fixtures and explicit chosen/claimed/trusted time regression. Existing `crypto.rs` OCSP fixtures corrected.
- `crates/engine/tests/signature_workflow.rs`: real local HTTP timestamps, MIME/redirect/untrusted refusal, response/deadline/cancel limits, closed/edited-result rejection, detached DSS save, URL/date strictness.
- `crates/automation/tests/signature_workflow.rs`: local authority sign+timestamp then document timestamp, opt-in/root restrictions, DSS/reopen and time-provenance workflow.
- `crates/ui-egui/tests/signature_workflow.rs`: profile persistence/opt-in, inline completed-result cancellation, edited-document stale result, DSS save/reopen, selected-time verification, real dialog-button timestamp save/reopen against local TCP authority.
- `timestamp_ui::tests::signature_state_is_inspectable_without_sending_a_request`: control inspection fields, no worker/request.

After the new owner approves a build slot/disk target, from this worktree:

```sh
cargo test -p pdfcraft-sign --test crypto --test pdf --test timestamp_workflow --test evidence_workflow -- --test-threads=2
cargo test -p pdfcraft-engine --test signature_workflow -- --test-threads=2
cargo test -p pdfcraft-automation --test signature_workflow -- --test-threads=2
cargo test -p pdfcraft-ui-egui --lib timestamp_ui::tests -- --test-threads=2
cargo test -p pdfcraft-ui-egui --test signature_workflow --test signing -- --test-threads=2
cargo clippy -p pdfcraft-sign -p pdfcraft-engine -p pdfcraft-automation -p pdfcraft-ui-egui --all-targets -- -D warnings
```

Use the established shared Cargo/disk scheduling policy; do not launch these concurrently with the PDF checkpoint blindly. New OpenSSL gates intentionally require the local `openssl` executable. Check target/platform conventions before wasm/Windows compilation; native transport is refused on wasm. Follow with repository-required broader checks and an actual packaged native UI receipt before claiming completion.

## Review risks / next actions

1. This entire delta is uncompiled: expect ordinary type/borrow/Clippy fixes and test expectations to need adjustment. Review the frozen diff first and run sign-only gates before the expensive UI graph.
2. Test syntax/fixtures were source-reviewed only. In particular, verify OpenSSL command compatibility and the independently generated TSA/CRL/OCSP structures; do not weaken assertions to make an invalid fixture pass.
3. Existing revocation behavior beyond ENUMERATED was not redesigned. Its delegated OCSP certificate extraction appears to walk `certs [0] EXPLICIT SEQUENCE OF Certificate` at the wrong nesting level; inspect and add a correct delegated responder fixture before claiming all OCSP responder paths. Missing `nextUpdate` currently has the preexisting unrestricted upper window. Fresh-evidence/maximum-age and archival policy remain open.
4. Transport trust validates the TSA chain and issuance validity, but does not fetch revocation information. The workflow is not a blanket long-term-validity or legal-signature claim.
5. Local evidence coverage currently checks document signer chains; embedded timestamp authority chains are not separately included in the complete-coverage report. This is one reason no B-LT/B-LTA conformance claim is made. The UI only reports notes after save; a richer review-before-save coverage report is still desirable.
6. Confirm ordinary signature, invalid/untrusted timestamp and signed-document metadata cases against the existing corpus. Explicit-time verification is a separate report; ordinary panel validation remains best-available. Keep provenance clear.
7. Root trust is explicit and certificates are not auto-imported. Preserve this and failure-before-save behavior during fixes. Cancellation may wait up to the HTTP deadline; no partial PDF result should be saved after cancel.
8. UI/save/code paths have test sources but no runtime evidence yet. Profiles, selected server, network opt-in and result fields need actual control/AccessKit checks. Evidence import currently uses newline-separated paths rather than a multi-file picker.
9. New schemas and commands are additive, but registry/tool tests may require updated expectations. Do not blindly reformat or overwrite the PDF lead's main shared files during integration.
10. After successful gates, update parity H rows/roadmap with evidence and remaining gaps; the new timestamp catalogue entries are already marked Ready in source, so do not ship them without the gates.

## User stop

User requested finishing the current atomic edit then pausing for Claude. Formatting and recovery artifacts complete that edit. No new feature, build, network request or test was started after the stop. Continue only under the next owner's resumed task.
