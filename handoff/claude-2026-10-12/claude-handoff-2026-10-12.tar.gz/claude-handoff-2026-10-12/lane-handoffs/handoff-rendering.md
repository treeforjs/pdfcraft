# PdfCraft rendering handoff

Paused at the user's request on 2026-10-12. This entire candidate is uncommitted,
uncompiled and untested. Do not mistake its documentation or added tests for completed
validation. No rendering changes are in the pushed checkpoint or current main checkout.

Worktree: `/workspace/pdfcraft-rendering`, branch `feature/pdf-rendering-parity-2026-10-12`,
base `6cab152bc24f80629627ad928e327027088727c4`.

Recovery: `rendering-frozen/{tracked.patch,new-source-files.tar.gz,state.json}` alongside
this file. The manifest hashes all 12 modified/new files. Patch SHA256:
`5f5a823ba4ea87d724e052660119fbdbd8d344085958c2216a4c85ad55e82b7f`.

## Candidate scope

Original strict vector lexer/compiler/display list and Vello CPU device for solid Gray/RGB
paths, fills, winding, strokes, caps/joins/miter/dash state, q/Q, clipping, CTM, crop/rotation
and tiles. The path captures CTM during construction; the pen uses painting CTM. Native
pages are attempted automatically through the common `render_page` path, with one bounded
positive/negative page cache per worker/parser generation and whole-page bootstrap fallback.

The syntax/page reader is still hayro. Text/fonts, images, forms, CMYK, patterns, shading,
transparency, annotations, replacement device spaces and explicit UserUnit all fall back.
This is an M2 foundation, not an independent full renderer or completed parity feature.

Main files: `crates/render/src/display_list.rs`, its `lexer.rs`/tests, `vector_raster.rs`,
its `decode.rs`/tests, cache hooks in `raster.rs`, dependency/lockfile changes and
`docs/native-vector-rendering.md`. `vendor/hayro-syntax/src/object/stream.rs` has a narrow
`raw_data_within` method checking actual encoded bytes before decryption allocation.

## Review findings and final source corrections

Runtime independently reviewed initial source. CTM/clip ordering looked coherent, but
review is incomplete. See `pdf-native-vector-initial-source-review.json` and
`handoff-runtime-review.md`.

- Initial use of tolerant COS/content parsing exposed quadratic malformed-number prefix
  repair on the default rendering path. Final source replaces that parser with a strict
  linear vector lexer: numeric tokens at most 64 bytes, six operands, 256 dash items,
  immediate refusal of unsupported syntax, per-token/comment cancellation. Added original
  malformed-number/huge-token/comment-cancellation tests. This replacement is not re-reviewed.
- Bootstrap stream decoding could return partial/intermediate-truncated buffers. Final
  source uses bounded `pdfcraft-filters` decoding, validates chain/parameter types/counts,
  checks actual encoded size before decryption and enforces intermediate output limits.
- Several compatibility filters accept missing EOD. Final source conservatively supports
  only unfiltered and Flate native content (Flate requires deflate StreamEnd). Other codecs
  fall back until explicit framing checks exist. `/F`, `/FFilter`, `/FDecodeParms`, `/DP`
  are rejected. These final corrections are not re-reviewed or tested.
- PDF stroke defaults are explicitly butt/miter/limit10, rather than Kurbo defaults.
  Direct raster test fixtures now explicitly request white backgrounds.

## Remaining work before integration

1. Re-review strict lexer, filter framing, array resolution and cache lifetime; complete
   resource review of stroke inverse geometry, curve flattening, clipping and dash work.
   Current budgets include 1MiB decoded content, 100k operators/segments, 25k draws,
   256 states/clips, 65536 retained clip references and a 4M device-work estimate. These
   constants are candidate bounds, not proof that every backend allocation is bounded.
2. Compile and repair ordinary type/borrow/API/Clippy errors; no Cargo has run here.
3. Run focused render tests and existing whole renderer/pool/watchdog/large-page tests.
   Add independent bootstrap and external Poppler comparisons for anisotropic/sheared
   strokes, caps/joins/dashes and CTM changes after constructing a path. Current original
   tests cover basic fill/clip pixels, compiler state, tile equivalence, fallback and limits.
4. Measure fallback overhead on representative text/image PDFs and native vector pages.
   Do not regress lazy/shared parser memory or responsiveness. Review the cancellation and
   panic paths with the existing pool tests.
5. Update vendor patch inventory and documentation after gates. Then integrate contextually
   into main, preserving the already delivered text editing and later integrated lanes.
   Run repository-required native/WASM/Clippy/assets/layers/parity gates before commit.

Only direct rustfmt parsing and `git diff --check` passed. Source is frozen; no build or
oracle process remains running for this lane.
