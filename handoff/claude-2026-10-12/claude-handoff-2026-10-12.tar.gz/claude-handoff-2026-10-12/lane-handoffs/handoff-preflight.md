# PdfCraft preflight handoff — paused 2026-10-12

The user requested a pause and handoff to Claude. This lane is frozen. Do not start more
work, builds, commits or pushes until the user resumes. No preflight commit has been made.

## Authoritative source and recovery

- Main checkout: `/workspace/pdfcraft`, branch `feature/full-parity-2026-10-12`.
- HEAD: `994698dde20a97cc41eccd17552f1797d7dd2298`. Preflight changes are **uncommitted**:
  17 modified tracked files plus 9 new source/document files, 26 files total.
- Original isolated worktree: `/workspace/pdfcraft-preflight`, branch
  `feature/pdf-preflight-parity-2026-10-12`, based on `6cab152`. It contains the initial
  implementation and synced final core/new UI modules. Main is authoritative for final
  integration, metadata, evidence and shared-file context; do not merge the old worktree
  wholesale over main.
- Durable recovery artifacts are under
  `/workspace/ubuntu-support/full-parity-2026-10-12/preflight-handoff/`:
  `pdfcraft-preflight-integrated.patch` (binary-safe tracked diff against main HEAD),
  `pdfcraft-preflight-integrated-untracked.txt`,
  `pdfcraft-preflight-integrated-untracked.tar.gz` (the nine new files), and
  `pdfcraft-preflight-integrated.sha256` (all 26 final source hashes).
- Tracked patch SHA-256:
  `b4481ccc53e3bba67ad9f05a160f7c08e9930831e884047b34d9597ece021031`.
- All 26 current main files matched the final source receipt immediately before this
  handoff. The patch is already applied; do not apply it again to the present checkout.

Integration preserved the existing text-editing checkpoint. Only ROADMAP log context and
the engine module-registration context conflicted with the older worktree base; those were
resolved by inserting only the preflight-specific hunks. Root authorized this integration
and focused build slot, but explicitly deferred full centralized gates and commits.

## Implemented behavior

The new `preflight.run` native dialog and headless tools provide four structural profiles
(General, Print, PDF/A-2b, PDF/A-3b), supported single checks, grouped findings with indirect
object/generation and direct dictionary/array paths, known page links, explicit selected
fixes, and text/JSON reporting. The native dialog exports text; JSON export is headless.

The eight general checks cover embedded font-program presence, additional actions, image
interpolation, annotation print flags, external streams, LZW compression, transparency
groups and embedded file specifications. PDF/A profiles add bounded XMP identification
and encryption checks. These do not constitute full ISO validation.

Four explicit fixups are implemented: disable image interpolation, OR the annotation print
bit while retaining all other flags, remove only a selected additional-action dictionary,
and recompress decoded LZW streams with Flate. Selection binds the document revision and
exact original owner-object value plus direct path. All bindings are checked before edits;
the low-level operation mutates a clone and publishes only after success. Cancellation,
invalid selections, stale bindings and decode failures leave the document untouched. The
engine uses normal edit permissions and records the selection as one undo step.

LZW recompression accepts only direct filter/parameter descriptions, avoiding unbound
indirect decoding dependencies. It requires an explicit LZW end-of-data marker (the general
reader tolerates its absence), strict decoding, 32 MiB maximum per encoded/decoded stream,
and 128 MiB total decoded content per batch. Unsupported or corrupt chains fail atomically.

Traversal and retained findings/page links are bounded. Independent review by
`/root/parity_runtime` caught a deep/wide path-copy memory amplification; paths now share
`Arc<PathNode>` ancestry, with a separate 4 MiB total retained finding-key budget, and a
synthetic regression verifies that thousands of sibling paths share one ancestor chain.

The legacy `pdfa_verify`/`pdfa_convert` response keeps its `compliant` boolean field, now
conservatively false. It adds `no_detected_issues`, `validation_complete:false`,
`conformance:"not-established"`, and limitations. The PDF/A dialog no longer calls an empty
subset result full conformance. This is an intentional semantic tightening for compatibility
consumers and is documented in both preflight and automation READMEs.

## Source map

New files:

- `crates/preflight/src/analysis.rs` — bounded scanning, reports, exact-value fix bindings,
  atomic fixups and strict LZW end-marker framing.
- `crates/preflight/src/analysis/tests.rs` — nine new synthetic core tests.
- `crates/preflight/README.md` — capabilities, API compatibility and limits.
- `crates/engine/src/preflight.rs` and `crates/engine/src/preflight/tests.rs` — revision
  binding, guarded engine entry point, one-step history and focused tests.
- `crates/automation/src/preflight.rs` and `crates/automation/tests/preflight.rs` — profiles,
  analysis, selected fixes, confined atomic text/JSON reports and four end-to-end tests.
- `crates/ui-egui/src/preflight_ui.rs` and `crates/ui-egui/tests/preflight.rs` — native dialog,
  stable results layout, stale-result rejection, export and four native/direct UI tests.

Tracked wiring: preflight Cargo manifest/lib/test helper, one existing workspace filter
dependency in Cargo.lock; engine lib/commands/catalog; automation lib/tools/a11y; UI
lib/commands/dialogs/standards_ui. Documentation/evidence: ROADMAP, automation README and
seven K-area preflight rows in `parity/acrobat-features.toml`, all marked **partial** with
specific passing evidence and explicit omissions. No overall parity estimate increase.

## Validation completed

All 25 focused test executions passed (19 new tests plus six existing core regressions):

- `cargo test -p pdfcraft-preflight --lib` — 15 passed.
- `cargo test -p pdfcraft-engine --lib preflight::tests` — 2 passed.
- `cargo test -p pdfcraft-automation --test preflight` — 4 passed.
- `cargo test -p pdfcraft-ui-egui --test preflight` — 4 passed after fixing a real modal
  layout issue where clipped result controls could cause an outside-click dismissal.
- `cargo clippy -p pdfcraft-preflight --all-targets -- -D warnings` — passed.
- `cargo fmt --all --check` and `git diff --check` — passed.

Logs live under `/workspace/ubuntu-support/full-parity-2026-10-12/logs/`:
`pdf-preflight-engine.log`, `pdf-preflight-automation.log`, `pdf-preflight-ui.log`, and
`pdf-preflight-clippy.log`. The first core test result was observed in tool output rather
than a saved log; it passed all 15 cases. After test execution, final source changes were
two equivalent collapsed-if lint fixes and neutral singular/plural count wording in UI;
focused clippy and workspace formatting passed on those final sources.

Native screenshot:
`/workspace/ubuntu-support/full-parity-2026-10-12/preflight-native.png`.
It was visually inspected: profile/check controls, grouped finding, object reference and
page link are fully visible. The only subsequent visual change replaces the old count
wording with `Findings: … · Objects checked: …`. The screenshot is a local, synthetic
PdfCraft artifact and is not committed or published.

Independent source review was clear after the shared-path fix. No GPL/AGPL code or Adobe
assets were imported. No model/font/binary assets were downloaded for this lane.

## Remaining limits and next work

Full PDF/A validation is absent, including all content operators, font-program validation,
ICC/output-intent validity and associated-file/transparency requirements. PDF/X and PDF/UA
validation/conversion remain unimplemented. No veraPDF executable was available and no
independent validator comparison was performed. Declared metadata is not proof of
conformance. The old conversion implementation still exists independently; the new selected
fixups deliberately do not call it or overwrite XMP/add an assumed sRGB intent.

Custom saved profiles/profile exchange, PDF/XML reports, object snap views, droplets and
embedded audit trails remain unimplemented. Findings include unreferenced objects; empty
page association does not prove an object affects no page. Page association is best-effort
within disclosed traversal/output budgets, not a complete painted-object usage analysis.

Full workspace clippy/tests, wasm, asset/parity/release gates and installed-package checks
have **not** been rerun for these uncommitted changes. Root will centralize those after
resuming and integrating the other lanes. Do not commit until the required gates pass.

## Resume commands — not run after the user pause

First inspect `git status` and the source receipt, and coordinate main/build ownership.
The successful focused build environment was:

```sh
cd /workspace/pdfcraft
. /workspace/native-deps/env.sh
export CARGO_TARGET_DIR=/workspace/pdfcraft/target/agent-parity
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
unset CRAFT_FONTS_DIR
```

No DISPLAY, Xvfb, WGPU_BACKEND or renderer override was required for the native tests.
To refresh the focused evidence and exact final screenshot when authorized:

```sh
cargo test -p pdfcraft-preflight --lib
cargo test -p pdfcraft-engine --lib preflight::tests
cargo test -p pdfcraft-automation --test preflight
PDFCRAFT_PREFLIGHT_SHOT=/workspace/ubuntu-support/full-parity-2026-10-12/preflight-native.png cargo test -p pdfcraft-ui-egui --test preflight
cargo clippy -p pdfcraft-preflight --all-targets -- -D warnings
cargo fmt --all --check
git diff --check
```

Then let the coordinator run the repository-required centralized gates (`cargo xtask ci`,
or its documented equivalent workspace clippy/tests/wasm/assets/parity sequence), review
the integrated diff, and only then commit/push if authorized. Other agents have isolated
unfinished lanes; their handoffs must be consulted before further shared-file edits.
