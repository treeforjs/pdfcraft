# PdfCraft reader-selection handoff — paused for Claude

User explicitly stopped work to hand over to Claude. Do not infer that this source is tested or shipped.

- Worktree: `/workspace/pdfcraft-selection`
- Branch: `feature/pdf-reader-selection-2026-10-12`
- Base commit: `6cab152bc24f80629627ad928e327027088727c4`
- Status: dirty source-only worktree, uncommitted, unmerged. No Cargo/build/test execution in this lane.
- Binary-safe tracked diff: `/workspace/ubuntu-support/full-parity-2026-10-12/pdf-reader-selection-source/tracked.patch`
- Diff SHA-256: `49b1256029c45c9ae1b86b9a1ed6180a30362fbc63791cec7dd8c69da03968e5`
- New-source archive: `/workspace/ubuntu-support/full-parity-2026-10-12/pdf-reader-selection-source/new-source-files.tar.gz`
- Archive SHA-256: `015756df449f064a3d49ad04f42b99087cfa5b274cdc1947c3b69e01dc2079c5`
- Every final source hash, exact status and focused commands: `/workspace/ubuntu-support/full-parity-2026-10-12/pdf-reader-selection-source/state.json`

## Implemented source

Reader selections have cross-page anchor/head endpoints, reverse dragging, Shift extension,
blank-page boundaries, edge scrolling owned only by a text drag, document-wide Ctrl/Command+A,
layout-dependent four-click selection, and a Select paragraph context action. Whole-document
Copy waits for every selected text layer and never emits a partial result. A replacement selection,
Escape/Cancel, document invalidation, tab switch, modal/palette, window focus loss or text-editor
focus cancels pending clipboard work. Selection highlighting is retained on context changes.
Completion runs at the app's final frame boundary and rechecks current copy permission.

The engine module `reader_selection.rs` provides inclusive whole-glyph ranges, conservative
paragraph geometry and permission-checked sequential extraction with a 32 MiB UTF-8 bound.
The new `text_selection` tool exposes range/paragraph/all modes. `text_extract` now checks copy
permission and optionally exposes up to 200,000 glyph indices/rectangles. UI background selection
demand is progressively capped at 2 million glyphs or 32 MiB glyph text, with at most 32 missing
selected pages queued; an offscreen crossing page is not retained. `ui.state.active.text_selection`
reports selection/copy state and permission-filtered text with explicit 65,536-byte truncation.

## Validation and review

Direct rustfmt parsing/checks and `git diff --check` pass. **All 23 new tests are unexecuted**:
9 engine unit, 4 UI unit, 8 UI integration, 2 automation integration. Existing viewer Select All
expectations were updated too. Native compilation, Clippy, full tests, WASM, asset/layer/parity gates,
and installed Ubuntu screenshots/clipboard checks have not run for this lane.

Runtime agent's scoped source review found and then cleared stale-selection drag ownership,
same-frame cancellation, progressive-cache and context-loss concerns. The final context-loss test
checks tab/modal/palette/window/editor cases and proves clipboard work does not resume on return.
This is source review, not runtime or test certification.

## Ownership and integration

Own files: canvas.rs, text_select.rs, viewer.rs expectation, new engine/automation reader_selection
modules/tests, docs/reader-selection.md. Small shared hooks: engine/lib.rs module declaration;
automation/lib.rs dispatch and text_extract; automation/tools.rs schemas; UI/lib.rs permission and
final-frame authority handling; UI/control.rs state field. Fourteen TSV catalogs add only the
Select paragraph label. ROADMAP records this as an unvalidated candidate; shipping labels stay
unchanged. No renderer, font, edit-text or text-preview implementation files were changed.

Root planned preflight integration first, then this reader lane into the consolidated
`/workspace/pdfcraft` checkout. Reconcile shared hooks against the current validated PDF HEAD;
this source is based on earlier wave1 HEAD above. Reuse the existing consolidated build target,
not a new worktree target. Preserve M7/preflight fixes. Do not overwrite their shared files wholesale.

## Next commands after integration/build-slot authorization

```bash
source /workspace/native-deps/env.sh
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TARGET_DIR=target/agent-parity
cargo test -p pdfcraft-engine --lib reader_selection
cargo test -p pdfcraft-ui-egui --lib reader_selection
cargo test -p pdfcraft-ui-egui --lib replacing_a_pending_selection
cargo test -p pdfcraft-ui-egui --lib reader_copy_loses_authority
cargo test -p pdfcraft-ui-egui --test text_select --test viewer
cargo test -p pdfcraft-automation --test reader_selection
```

Fix actual compiler/test findings, then run the complete repository gates (native, lint, WASM,
assets/layers/parity) before commits. Keep job count1 and monitor shared disk. Inspect real installed
Ubuntu24/26 X11/Wayland behavior/screenshots on original synthetic PDFs. Use the context-menu Copy
button in control-channel checks: current `ui.key` injects Key events but does not synthesize OS
`Event::Copy` from Ctrl+C. `text_selection` and glyph-inspection data provide the headless comparison.
After passing, replace the pending ROADMAP/docs text and cite specific evidence in the three reader
manifest rows; do not increase overall parity estimates from labels alone.

## Honest limits

Reading order is the existing geometric extractor, not full tagged-PDF/bidi/complex-layout parity.
Paragraph boundaries are heuristic for untagged content. Multi-page annotation creation and
copy-with-layout remain separate. The copy/cache limits are explicit errors, not silent truncation.
No proprietary application, asset, code or output was inspected. Public reference:
https://helpx.adobe.com/acrobat/using/reusing-pdf-content.html and ISO32000-2 Table22.

The earlier Vector checkpoint remains independently paused/uncommitted at
`/workspace/ubuntu-support/full-parity-2026-10-12/vector-paused-checkpoint/state.json`; full native CI there was cancelled before executing
workspace tests. Do not treat its focused test results as a completed full gate.
